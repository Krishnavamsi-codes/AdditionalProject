"""Matching: mutual nearest neighbour (the RIPE / glue-factory protocol for sparse methods),
optional Lowe ratio test. Exactly the same matcher is used for baseline and enhanced variants."""
import numpy as np


def _dist(d0, d1, binary):
    if binary:  # Hamming distance via bit-unpacking + matmul
        a = np.unpackbits(d0, axis=1).astype(np.float32)
        b = np.unpackbits(d1, axis=1).astype(np.float32)
        return a.sum(1)[:, None] + b.sum(1)[None] - 2 * a @ b.T
    a = d0.astype(np.float32); b = d1.astype(np.float32)
    d2 = (a * a).sum(1)[:, None] + (b * b).sum(1)[None] - 2 * a @ b.T
    return np.sqrt(np.maximum(d2, 0))


def mnn(d0, d1, binary=False, ratio=None, return_dist=False):
    """Return int array [M,2] of mutual nearest neighbours (+ optional ratio test)."""
    if len(d0) < 2 or len(d1) < 2:
        z = np.zeros((0, 2), int)
        return (z, np.zeros(0)) if return_dist else z
    D = _dist(d0, d1, binary)
    nn01 = D.argmin(1)
    nn10 = D.argmin(0)
    i0 = np.arange(len(d0))
    keep = nn10[nn01] == i0
    if ratio:
        part = np.partition(D, 1, axis=1)[:, :2]
        keep &= part[:, 0] <= ratio * part[:, 1]
    m = np.stack([i0[keep], nn01[keep]], 1)
    if return_dist:
        return m, D[m[:, 0], m[:, 1]]
    return m
